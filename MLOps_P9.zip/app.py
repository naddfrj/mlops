from flask import Flask, request, jsonify

app = Flask(__name__)
model = joblib.load("model.pkl")

@app.route('/product', methods=['POST'])
def predict():
  data = request.get_json()
  features = np.array(data["features"]).reshape(1, -1)
  pred = model.predict(features).tolist()
  return jsonify({"prediction": pred})

if__name__ == "__main__":
  app.run(host="0.0.0.0", port=5000)
